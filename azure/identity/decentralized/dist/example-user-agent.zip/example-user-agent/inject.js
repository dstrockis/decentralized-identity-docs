window.navigator.did = {
    didAuthentication: (did, nonce, state, onSuccess, onError) => {
        const request = {
            'client_id': did,
            'nonce': nonce,
            'state': state,
        };
        document.dispatchEvent(new CustomEvent('did-auth', { 'detail': request }));

        const callback = (response) => {
            const data = response.detail;
            if (data.success) {
                onSuccess(data.data);
            } else {
                onError(data.data);
            }
            document.removeEventListener('did-auth-response', callback);
        }
        document.addEventListener('did-auth-response', callback)
    }
}
