let authId;

const callback = (message) => {
    if (!authId) {
        return;
    }
    chrome.tabs.sendMessage(authId, message);
}

const manageIcon = (tabId) => {
    if (!authId) {
        return;
    }
    if (tabId && tabId == authId) {
        chrome.browserAction.setIcon({
            path: './assets/shield_attention_48.png'
        });
        // chrome.browserAction.setBadgeText({
        //     text: "!",
        //     tabId: authId
        // });
    } else {
        // chrome.browserAction.setBadgeText({
        //     text: "",
        //     tabId: authId
        // });
        chrome.browserAction.setIcon({
            path: './assets/shield_blue_48.png'
        });
    }
}

chrome.runtime.onMessage.addListener((message, sender, returnCaller) => {
    if (authId) {
        // cancel previously active request
        callback({
            "success": false,
            "data": "fail.timeout"
        });
    }
    authId = sender.tab.id;
    localStorage.setItem('did-auth', JSON.stringify(message));
    console.log('message: ' + message);
    manageIcon(sender.tab.id);
    returnCaller();
});

window.addEventListener('storage', (event) => {
    if (authId) {
        if (event.key === 'did-auth-response') {
            const value = event.newValue;
            manageIcon();
            if (value === "") {
                callback({
                    "success": false,
                    "data": "fail.ua"
                });
            } else {
                callback({
                    "success": true,
                    "data": value
                })
            }
            localStorage.removeItem('did-auth-response');
            authId = undefined;
        }
    }
});

// change state based on tab
chrome.tabs.onActivated.addListener((activeInfo) => {
    manageIcon(activeInfo.tabId);
});

// change state based on web navigation
chrome.webNavigation.onCommitted.addListener((details) => {
    if (details.tabId == authId) {
        // remove the request if the request tab navigates
        localStorage.removeItem('did-auth');
        authId = undefined;
        manageIcon(details.tabId);
    }
});