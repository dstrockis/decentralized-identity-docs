// Injected script
const inject = () => {
    window.navigator.did = {
        requestAuthentication: (authRequest) => {
            return new Promise((resolve, reject) => {
                const requestAuth = (authRequest, onSuccess, onError) => {
                    const request = {
                        'client_id': authRequest,
                    };
                    document.dispatchEvent(new CustomEvent('did-auth', { 'detail': request }));
            
                    const callback = (response) => {
                        const data = response.detail;
                        if (data.success) {
                            onSuccess(data.data);
                        } else {
                            onError(data.data);
                        }
                        document.removeEventListener('did-auth-response', callback);
                    }
                    document.addEventListener('did-auth-response', callback)
                };
                requestAuth(authRequest, resolve, reject);
            });
        }
    }
}

// bootstrap UA interfaces
const script = document.createElement('script');
script.textContent = "(" + inject + ")()";
document.head.appendChild(script);

// send responses
const callback = (message) => {
    document.dispatchEvent(new CustomEvent('did-auth-response', {
        detail: message
    }));
};

// handle messages
document.addEventListener('did-auth', function(request) {
    const challenge = {
        client_id: request.detail.client_id,
    };

    chrome.runtime.sendMessage(challenge);
});

chrome.runtime.onMessage.addListener((message) => {
    callback(message);
})